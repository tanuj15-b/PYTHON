class cart:
    def __init__(self):
        self.items={}
        self.price_details={"book":10,"lap":30000}
    def add_items(self,item,quantity):
        self.items[item]=quantity 
    def get_items(self):
        items_list=[]
        items_list=list(self.items.keys())
        print(items_list)
    def remove_items(self,item):
        del self.items[item]
    def update_quantity(self,item,quantity):
        self.items[item]=quantity
    def get_total_price(self):
        total_price=0
        for item,quantity in self.items.items():
            total_price += self.price_details[item] * quantity
        print(total_price)
obj=cart()
obj.add_items("book",10)
obj.get_items()
obj.add_items("lap",2)
obj.get_items()
obj.remove_items("book")
obj.get_items()
obj.update_quantity("lap",1)
obj.get_items()
obj.get_total_price()